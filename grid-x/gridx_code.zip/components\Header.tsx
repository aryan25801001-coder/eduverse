"use client";

import React, { useState, useEffect } from "react";
import { useStore } from "@/lib/store";
import { FiSun, FiZap, FiSettings, FiBell, FiShield, FiServer, FiRadio } from "react-icons/fi";
import { BiLeaf, BiNetworkChart, BiChevronDown, BiChip } from "react-icons/bi";
import { motion } from "framer-motion";

export default function Header() {
  const { user, isDisasterMode } = useStore();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`h-20 sticky top-0 z-50 transition-all duration-500 ${scrolled
          ? "bg-[#050510]/80 backdrop-blur-xl border-b border-white/5 shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
          : "bg-transparent border-b border-white/5"
        }`}
    >
      <div className="max-w-[1600px] mx-auto px-8 h-full flex items-center justify-between">
        {/* Logo Section */}
        <div className="flex items-center gap-12">
          <div className="flex items-center gap-4 group cursor-pointer">
            <div className={`relative flex items-center justify-center w-10 h-10 rounded-xl transition-all duration-500 transform group-hover:rotate-[360deg] ${isDisasterMode ? "bg-neon-red/20 text-neon-red" : "bg-accent/10 text-accent shadow-[0_0_15px_rgba(0,255,163,0.2)]"
              }`}>
              <FiSun className={`w-6 h-6 ${isDisasterMode ? "animate-pulse" : ""}`} />
              <div className="absolute inset-0 bg-accent/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tighter flex items-center gap-1">
                <span className="text-white">GRID</span>
                <span className={isDisasterMode ? "text-neon-red" : "text-accent"}>X</span>
              </h1>
              <div className="flex items-center gap-2">
                <div className={`w-1.5 h-1.5 rounded-full ${isDisasterMode ? "bg-neon-red animate-ping" : "bg-accent shadow-[0_0_8px_rgba(0,255,163,1)]"}`}></div>
                <p className="text-[9px] font-black text-gray-500 uppercase tracking-[0.2em]">
                  {isDisasterMode ? "Protocol Delta Active" : "Network v1.02 Secure"}
                </p>
              </div>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-1 bg-white/5 p-1 rounded-2xl border border-white/5">
            <HeaderTab label="Mainnet" icon={<FiServer />} active />
            <HeaderTab label="Mumbai" icon={<FiRadio />} />
            <HeaderTab label="AI Node" icon={<BiChip />} />
          </nav>
        </div>

        {/* Global Stats bar (Middle) */}
        <div className="hidden xl:flex items-center gap-16 border-x border-white/5 px-16 h-10">
          <StatItem label="Global Vol." value="14.8 GWh" />
          <StatItem label="Nodes Act." value="1,248" color="text-neon-cyan" />
          <StatItem label="Grid Health" value="99.9%" color="text-accent" />
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3">
            <HeaderActionButton icon={<FiBell />} badgeCount={3} />
            <HeaderActionButton icon={<FiSettings />} />
          </div>

          <div className="h-8 w-[1px] bg-white/10" />

          {/* Profile Dropdown */}
          <button className="flex items-center gap-4 pl-4 pr-1.5 py-1.5 rounded-2xl bg-white/5 hover:bg-white/10 transition-all border border-white/5 group">
            <div className="text-right hidden md:block">
              <p className="text-xs font-black text-gray-100 group-hover:text-accent transition-colors">{user?.name || "Arjun Solar Farm"}</p>
              <div className="flex items-center justify-end gap-1.5">
                <FiShield className="text-[10px] text-accent" />
                <p className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">{user?.role || "Operator"}</p>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-accent to-neon-cyan flex items-center justify-center text-black font-black text-sm relative shadow-[0_0_15px_rgba(0,255,163,0.3)]">
              {user?.name?.charAt(0) || "A"}
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-[#050510] flex items-center justify-center border border-white/10 group-hover:border-accent transition-colors">
                <BiChevronDown className="text-gray-500 group-hover:text-accent transition-colors" />
              </div>
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}

function StatItem({ label, value, color = "text-gray-300" }: { label: string; value: string; color?: string }) {
  return (
    <div className="text-center group cursor-default">
      <p className="text-[9px] font-black text-gray-600 uppercase tracking-[0.2em] leading-none mb-1 group-hover:text-gray-400 transition-colors">{label}</p>
      <p className={`text-sm font-black transition-all ${color} group-hover:scale-110 tracking-tight`}>{value}</p>
    </div>
  );
}

function HeaderTab({ label, icon, active = false }: { label: string; icon?: React.ReactNode; active?: boolean }) {
  return (
    <button className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center gap-2.5 ${active ? "bg-accent/10 text-accent shadow-[inset_0_0_10px_rgba(0,255,163,0.1)]" : "text-gray-600 hover:text-gray-300 hover:bg-white/5"
      }`}>
      {icon && <span className={`text-base ${active ? "text-accent" : "text-gray-500"}`}>{icon}</span>}
      {label}
    </button>
  );
}

function HeaderActionButton({ icon, badgeCount }: { icon: React.ReactNode; badgeCount?: number }) {
  return (
    <button className="w-11 h-11 flex items-center justify-center rounded-2xl bg-white/5 border border-white/5 text-gray-500 hover:text-accent hover:border-accent/30 transition-all relative group shadow-inner">
      <span className="text-xl transition-all duration-300 group-hover:scale-125 group-hover:rotate-12">{icon}</span>
      {badgeCount && (
        <span className="absolute -top-1 -right-1 w-5 h-5 bg-neon-red text-[8px] font-black text-white rounded-lg flex items-center justify-center border-2 border-[#050510] shadow-[0_0_10px_rgba(255,0,85,0.5)]">
          {badgeCount}
        </span>
      )}
    </button>
  );
}
