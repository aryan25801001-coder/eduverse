"use client";

import React, { useState, useEffect } from "react";
import { useStore } from "@/lib/store";
import { BiLeaf, BiPowerOff, BiGridAlt, BiHistory, BiTrophy, BiBarChartAlt2, BiServer, BiRefresh, BiNetworkChart } from "react-icons/bi";
import { FiTrendingUp, FiZap, FiActivity } from "react-icons/fi";
import { motion } from "framer-motion";

export default function Sidebar() {
  const { setDisasterMode, isDisasterMode, user, activeView, setActiveView, carbonWallet } = useStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <aside className="w-72 bg-[#050510]/80 backdrop-blur-2xl border-r border-white/5 p-6 flex flex-col h-[calc(100vh-80px)] sticky top-20 z-40 overflow-y-auto custom-scrollbar">
      <nav className="space-y-1.5 flex-1">
        <NavItem
          icon={<BiGridAlt />}
          label="Dashboard"
          active={activeView === 'dashboard'}
          onClick={() => setActiveView('dashboard')}
        />
        <NavItem
          icon={<FiZap />}
          label="Energy Market"
          active={activeView === 'market'}
          onClick={() => setActiveView('market')}
        />
        <NavItem
          icon={<BiHistory />}
          label="Trades History"
          active={activeView === 'history'}
          onClick={() => setActiveView('history')}
        />
        <NavItem
          icon={<BiTrophy />}
          label="Carbon Heroes"
          active={activeView === 'leaderboard'}
          onClick={() => setActiveView('leaderboard')}
        />
        <NavItem
          icon={<BiBarChartAlt2 />}
          label="Advanced Analytics"
          active={activeView === 'analytics'}
          onClick={() => setActiveView('analytics')}
        />
        <div className="py-2 opacity-20 border-b border-white/10 mx-4" />
        <NavItem
          icon={<BiServer />}
          label="GridX Operations"
          active={activeView === 'operations'}
          onClick={() => setActiveView('operations')}
        />
        <NavItem
          icon={<BiRefresh />}
          label="Sync Grid"
          active={activeView === 'sync-grid'}
          onClick={() => setActiveView('sync-grid')}
        />
        <NavItem
          icon={<BiNetworkChart />}
          label="Grid Stability"
          active={activeView === 'grid-stability'}
          onClick={() => setActiveView('grid-stability')}
        />
        <NavItem
          icon={<FiActivity />}
          label="Smart Meters"
          active={activeView === 'meters'}
          onClick={() => setActiveView('meters')}
        />
      </nav>

      <div className="space-y-6 pt-6 mt-6 border-t border-white/5">
        {/* Disaster Mode Toggle */}
        <button
          onClick={() => setDisasterMode(!isDisasterMode)}
          className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl transition-all relative overflow-hidden group ${isDisasterMode
            ? "bg-neon-red/10 border border-neon-red/50 text-neon-red shadow-[0_0_20px_rgba(255,0,85,0.2)]"
            : "bg-white/5 border border-white/5 text-gray-500 hover:border-accent/30 hover:text-accent"
            }`}
        >
          <div className="flex items-center gap-3 relative z-10">
            <BiPowerOff className={`w-5 h-5 ${isDisasterMode ? "animate-pulse" : ""}`} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">
              {isDisasterMode ? "System Isolated" : "Disaster Protocol"}
            </span>
          </div>
          <div className={`w-1.5 h-1.5 rounded-full relative z-10 ${isDisasterMode ? "bg-neon-red shadow-[0_0_8px_rgba(255,0,85,1)]" : "bg-white/10"}`}></div>
        </button>

        {/* User Mini Profile */}
        <div className="glass-card bg-white/5 p-4 flex items-center gap-4 hover:border-accent/20 transition-all duration-500">
          <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center text-black font-black text-sm shadow-[0_0_15px_rgba(0,255,163,0.3)]">
            {user?.name?.charAt(0) || "A"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-black text-gray-100 truncate tracking-tight">{user?.name || "Arjun Solar Farm"}</p>
            <p className="text-[10px] text-accent uppercase font-bold tracking-widest">{user?.role || "SELLER"}</p>
          </div>
        </div>

        {/* Carbon Wallet Quick View */}
        <div className="relative overflow-hidden p-5 rounded-2xl bg-gradient-to-br from-accent/10 to-transparent border border-accent/20 group">
          <BiLeaf className="absolute -bottom-2 -right-2 w-20 h-20 text-accent/5 group-hover:text-accent/10 transition-colors" />
          <div className="flex items-center gap-2 mb-2">
            <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
            <p className="text-[10px] text-gray-500 uppercase font-black tracking-[0.2em]">Liquid Assets</p>
          </div>
          <div className="flex items-end gap-2">
            <span className="text-2xl font-black text-accent tracking-tighter">
              {carbonWallet?.balance?.toLocaleString() || "1,250"}
            </span>
            <span className="text-[10px] text-gray-500 font-bold mb-1.5">VCC</span>
          </div>
        </div>
      </div>
    </aside>
  );
}

function NavItem({
  icon,
  label,
  active = false,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-500 relative group truncate ${active
        ? "bg-accent/10 text-accent shadow-[inset_0_0_15px_rgba(0,255,163,0.05)] border border-accent/20"
        : "text-gray-500 hover:bg-white/5 hover:text-gray-200"
        }`}
    >
      <span className={`text-xl transition-all duration-500 group-hover:scale-125 ${active ? "text-accent drop-shadow-[0_0_8px_rgba(0,255,163,0.5)]" : "text-gray-600 group-hover:text-gray-400"}`}>
        {icon}
      </span>
      <span className="text-[11px] font-black uppercase tracking-[0.15em]">{label}</span>

      {active && (
        <motion.div
          layoutId="sidebar-active"
          className="absolute right-4 w-1 h-3 bg-accent rounded-full shadow-[0_0_10px_rgba(0,255,163,1)]"
        />
      )}
    </button>
  );
}
