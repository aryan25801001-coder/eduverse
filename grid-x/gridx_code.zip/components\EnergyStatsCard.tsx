"use client";

import React from "react";
import { motion } from "framer-motion";

interface Props {
  title: string;
  value: string | number;
  unit: string;
  icon: React.ReactNode;
  trend?: "up" | "down";
  trendValue?: string;
  color?: string;
}

export default function EnergyStatsCard({
  title,
  value,
  unit,
  icon,
  trend,
  trendValue,
  color = "accent",
}: Props) {
  const isUp = trend === "up";

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="glass-card p-6 relative group overflow-hidden"
    >
      {/* Dynamic Background Glow */}
      <div className={`absolute -right-4 -top-4 w-24 h-24 rounded-full blur-3xl opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
        style={{ backgroundColor: color === 'accent' ? '#00ffa3' : color === 'neon-yellow' ? '#fbff00' : '#00f2ff' }} />

      <div className="flex justify-between items-start mb-6">
        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 group-hover:border-accent/20 group-hover:bg-accent/5 transition-all duration-500 shadow-inner">
          <div className="text-2xl transition-all duration-500 group-hover:scale-125 group-hover:rotate-12">
            {icon}
          </div>
        </div>

        {trendValue && (
          <div className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-[10px] font-black tracking-widest uppercase ${isUp ? "bg-accent/10 text-accent" : "bg-neon-red/10 text-neon-red"
            }`}>
            <span>{isUp ? "↑" : "↓"}</span>
            <span className="font-mono">{trendValue}</span>
          </div>
        )}
      </div>

      <div className="space-y-1 relative z-10">
        <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em]">{title}</p>
        <div className="flex items-baseline gap-2">
          <h2 className="text-3xl font-black text-white tracking-tighter group-hover:text-accent transition-colors">
            {value}
          </h2>
          <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">{unit}</span>
        </div>
      </div>

      {/* Modern Progress Line Decoration */}
      <div className="absolute bottom-0 left-0 h-[3px] bg-gradient-to-r from-transparent via-accent/30 to-transparent w-0 group-hover:w-full transition-all duration-700" />
    </motion.div>
  );
}
