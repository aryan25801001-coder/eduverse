import type { Metadata } from "next";
import { Outfit } from "next/font/google";
import "./globals.css";

const outfit = Outfit({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "GridX | Decentralized AI Energy Trading",
  description: "Next-generation P2P energy sharing platform with real-time AI optimization.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${outfit.className} bg-primary text-gray-100 antialiased`}>
        <div className="glow-mesh" />
        <div className="bg-grid absolute inset-0 opacity-10 pointer-events-none" />
        <div className="min-h-screen relative z-10">
          {children}
        </div>
      </body>
    </html>
  );
}

