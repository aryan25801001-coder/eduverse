"use client";

import React, { useState } from "react";
import { FiZap, FiArrowRight, FiCheckCircle, FiUploadCloud } from "react-icons/fi";
import { motion, AnimatePresence } from "framer-motion";

export default function BuySell() {
  const [amount, setAmount] = useState(5);
  const [buyingStatus, setBuyingStatus] = useState(false);
  const [sellingStatus, setSellingStatus] = useState(false);
  const price = 5.20;
  const total = amount * price;

  const handleCompletePurchase = () => {
    setBuyingStatus(true);
    setTimeout(() => {
      setBuyingStatus(false);
      setAmount(5);
    }, 2000);
  };

  const handleListForSale = () => {
    setSellingStatus(true);
    setTimeout(() => {
      setSellingStatus(false);
    }, 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* BUY Section */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="glass-card p-10 relative group border-accent/20 overflow-hidden"
      >
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-accent/10 rounded-full blur-3xl group-hover:bg-accent/20 transition-all duration-700" />

        <div className="relative z-10 space-y-8">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 bg-accent/10 rounded-2xl flex items-center justify-center border border-accent/20 shadow-[0_0_15px_rgba(0,255,163,0.1)]">
              <FiZap className="text-accent text-3xl animate-pulse" />
            </div>
            <div>
              <h3 className="text-3xl font-black text-white uppercase tracking-tighter">Energy Acquisition</h3>
              <p className="text-[10px] text-accent/60 font-black uppercase tracking-[0.3em]">Purchase Clean Quotas</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-3">
              <div className="flex justify-between items-end">
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Amount to Purchase</p>
                <p className="text-2xl font-black text-white">{amount} <span className="text-xs text-gray-500 font-bold uppercase tracking-widest">kWh</span></p>
              </div>
              <input
                type="range"
                min="0.5"
                max="20"
                step="0.5"
                value={amount}
                onChange={(e) => setAmount(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-white/5 rounded-full appearance-none cursor-pointer accent-accent"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-white/5 border border-white/5 rounded-2xl">
                <p className="text-[10px] font-black text-gray-600 uppercase mb-1 tracking-widest">Current Rate</p>
                <p className="text-xl font-black text-neon-cyan tracking-tighter">₹{price.toFixed(2)}<span className="text-[10px] text-gray-500 ml-1">/UNIT</span></p>
              </div>
              <div className="p-4 bg-accent/5 border border-accent/10 rounded-2xl shadow-inner">
                <p className="text-[10px] font-black text-accent/60 uppercase mb-1 tracking-widest">Calculated Cost</p>
                <p className="text-xl font-black text-accent tracking-tighter">₹{total.toFixed(2)}</p>
              </div>
            </div>

            <button
              disabled={buyingStatus}
              onClick={handleCompletePurchase}
              className={`w-full py-5 rounded-2xl font-black transition-all duration-500 uppercase text-xs tracking-[.3em] flex items-center justify-center gap-3 active:scale-95 ${buyingStatus
                  ? "bg-white/10 text-gray-500 cursor-not-allowed"
                  : "bg-accent text-black hover:shadow-[0_0_30px_rgba(0,255,163,0.4)]"
                }`}
            >
              <AnimatePresence mode="wait">
                {buyingStatus ? (
                  <motion.div
                    key="buying"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center gap-2"
                  >
                    <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    Connecting...
                  </motion.div>
                ) : (
                  <motion.div
                    key="buy"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-center gap-3"
                  >
                    <FiCheckCircle className="text-xl" />
                    Confirm Procurement
                    <FiArrowRight />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>
      </motion.div>

      {/* SELL Section */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.1 }}
        className="glass-card p-10 relative group border-neon-yellow/20 overflow-hidden"
      >
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-neon-yellow/10 rounded-full blur-3xl group-hover:bg-neon-yellow/20 transition-all duration-700" />

        <div className="relative z-10 space-y-8">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 bg-neon-yellow/10 rounded-2xl flex items-center justify-center border border-neon-yellow/20">
              <FiUploadCloud className="text-neon-yellow text-3xl" />
            </div>
            <div>
              <h3 className="text-3xl font-black text-white uppercase tracking-tighter">Liquidize Surplus</h3>
              <p className="text-[10px] text-neon-yellow/60 font-black uppercase tracking-[0.3em]">Monetize Generation</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="p-6 bg-white/5 border border-white/5 rounded-2xl flex justify-between items-center group-hover:border-neon-yellow/20 transition-all">
              <div>
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Available to List</p>
                <p className="text-3xl font-black text-neon-yellow tracking-tighter">8.50 <span className="text-xs text-gray-500">kWh</span></p>
              </div>
              <div className="h-10 w-[1px] bg-white/10" />
              <div className="text-right">
                <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-1">Estimated ROI</p>
                <p className="text-xl font-black text-white tracking-tighter">₹44.20+</p>
              </div>
            </div>

            <div className="p-5 bg-gradient-to-r from-neon-green/10 to-transparent border-l-4 border-neon-green rounded-r-2xl">
              <p className="text-[10px] font-black text-neon-green uppercase tracking-widest mb-1">Market Multiplier Active</p>
              <p className="text-xs text-gray-400 font-medium">Earn <span className="text-white font-black">+4 Carbon Credits</span> per 5kW listed during peak hours.</p>
            </div>

            <button
              disabled={sellingStatus}
              onClick={handleListForSale}
              className={`w-full py-5 rounded-2xl font-black transition-all duration-500 uppercase text-xs tracking-[.3em] flex items-center justify-center gap-3 active:scale-95 ${sellingStatus
                  ? "bg-white/10 text-gray-500 cursor-not-allowed"
                  : "bg-white/10 border border-white/10 text-white hover:bg-neon-yellow hover:text-black hover:border-neon-yellow hover:shadow-[0_0_30px_rgba(251,255,0,0.3)]"
                }`}
            >
              <AnimatePresence mode="wait">
                {sellingStatus ? (
                  <motion.div
                    key="listing"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center gap-2"
                  >
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Transmitting...
                  </motion.div>
                ) : (
                  <motion.div
                    key="list"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-center gap-3"
                  >
                    <FiUploadCloud className="text-xl" />
                    List for Trading
                    <FiArrowRight />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
