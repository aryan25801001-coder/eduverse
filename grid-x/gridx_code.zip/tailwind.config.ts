import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './lib/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#050510',
        secondary: '#0a0a25',
        card: 'rgba(15, 15, 45, 0.7)',
        accent: '#00ffa3', // Electric Teal/Green
        neon: {
          green: '#00ffa3',
          yellow: '#fbff00',
          red: '#ff0055',
          cyan: '#00f2ff',
          pink: '#ff00d4',
          purple: '#bc00ff',
        },
      },
      boxShadow: {
        glow: '0 0 20px rgba(0, 255, 0, 0.5)',
        'glow-red': '0 0 20px rgba(255, 0, 0, 0.5)',
        'glow-yellow': '0 0 20px rgba(255, 255, 0, 0.5)',
      },
      animation: {
        pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        blink: 'blink 1s infinite',
        float: 'float 3s ease-in-out infinite',
      },
      keyframes: {
        blink: {
          '0%, 49%': { opacity: '1' },
          '50%, 100%': { opacity: '0.3' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
    },
  },
  plugins: [],
}
export default config
